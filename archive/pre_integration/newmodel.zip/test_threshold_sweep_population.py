"""
Regression test for P1 (FINAL_PRODUCTION_READINESS_REPORT.md §12): the
threshold sweep must include S1 entities with zero blocked candidates in
its truth/pred population when `candidate_pairs_path` is supplied, matching
how the real submission (run_inference) scores them -- not silently drop
them the way load_candidate_pairs() does upstream for feature computation.
"""
import json
import pandas as pd
import pytest

from src.threshold import sweep_threshold


def _write_val_preds(path, rows):
    pd.DataFrame(rows).to_parquet(path, index=False)


def _write_gt(path, rows):
    pd.DataFrame(rows).to_csv(path, sep="\t", index=False)


def _write_candidate_pairs(path, rows):
    pd.DataFrame(rows).to_csv(path, sep="\t", index=False)


def test_zero_candidate_entity_with_true_match_is_included_and_scores_zero(tmp_path):
    # S1-A has candidates, scores well -> should be a true positive at low t.
    # S1-ZERO has a real ground-truth match but ZERO blocked candidates: it
    # must now appear in the population with an unavoidable F0.5=0.
    val_preds_path = tmp_path / "val_preds.parquet"
    gt_path = tmp_path / "gt.tsv"
    cp_path = tmp_path / "candidate_pairs.tsv"
    out_path = tmp_path / "threshold.json"

    _write_val_preds(val_preds_path, [
        {"source1_entity_id": "S1-A", "candidate_entity_id": "S2-A", "score": 0.9},
    ])
    _write_gt(gt_path, [
        {"source1_entity_id": "S1-A", "matched_entity_ids": "S2-A"},
        {"source1_entity_id": "S1-ZERO", "matched_entity_ids": "S2-GHOST"},  # unreachable: no candidates
    ])
    _write_candidate_pairs(cp_path, [
        {"source1_entity_id": "S1-A", "candidate_entity_ids": "S2-A"},
        {"source1_entity_id": "S1-ZERO", "candidate_entity_ids": ""},  # zero candidates
    ])

    # WITHOUT the fix (no candidate_pairs_path): S1-ZERO is invisible.
    result_old_style = sweep_threshold(val_preds_path, gt_path, out_path)
    assert result_old_style["n_population"] == 1 if "n_population" in result_old_style else True

    # WITH the fix: S1-ZERO must be counted.
    result = sweep_threshold(val_preds_path, gt_path, out_path, candidate_pairs_path=cp_path)
    assert result["n_with_candidates"] == 1
    assert result["n_zero_candidates_included"] == 1
    assert result["n_population"] == 2

    with open(out_path) as f:
        saved = json.load(f)
    assert saved["n_zero_candidates_included"] == 1


def test_zero_candidate_true_singleton_is_included_and_scores_one(tmp_path):
    val_preds_path = tmp_path / "val_preds.parquet"
    gt_path = tmp_path / "gt.tsv"
    cp_path = tmp_path / "candidate_pairs.tsv"
    out_path = tmp_path / "threshold.json"

    _write_val_preds(val_preds_path, [
        {"source1_entity_id": "S1-A", "candidate_entity_id": "S2-A", "score": 0.9},
    ])
    _write_gt(gt_path, [
        {"source1_entity_id": "S1-A", "matched_entity_ids": "S2-A"},
        {"source1_entity_id": "S1-SINGLETON", "matched_entity_ids": ""},  # true singleton, zero candidates
    ])
    _write_candidate_pairs(cp_path, [
        {"source1_entity_id": "S1-A", "candidate_entity_ids": "S2-A"},
        {"source1_entity_id": "S1-SINGLETON", "candidate_entity_ids": ""},
    ])

    result = sweep_threshold(val_preds_path, gt_path, out_path, candidate_pairs_path=cp_path)
    # A true singleton with an (unavoidably) empty prediction scores F0.5=1,
    # so including it should not hurt max_f05 -- with only S1-A and a
    # perfect singleton, macro F0.5 at the best threshold should still be 1.0.
    assert result["max_f05"] == pytest.approx(1.0)
    assert result["n_zero_candidates_included"] == 1


def test_threshold_selection_argmax_is_unaffected_by_the_fix():
    """Mathematical property documented in threshold.py: adding
    threshold-invariant zero-candidate entities to a macro-averaged metric
    is a positive affine transform of the f05(t) curve, so it must not
    change which threshold is selected -- only the reported max_f05 value."""
    import numpy as np
    # Simulate directly against eval.macro_f05 rather than sweep_threshold,
    # to isolate the mathematical claim from I/O plumbing.
    from eval import macro_f05

    # A toy "curve": f05 at a few candidate thresholds, for the val-only population.
    val_curve = {0.3: 0.60, 0.5: 0.80, 0.7: 0.55}  # t=0.5 is the argmax
    # zero-candidate contribution is constant across t (say 2 entities, one
    # scoring 0 (missed true match), one scoring 1 (true singleton) -> mean 0.5)
    zero_contrib_mean = 0.5
    n_val = 10  # pretend val-only population size
    n_zero = 4

    old_argmax = max(val_curve, key=val_curve.get)
    combined = {
        t: (v * n_val + zero_contrib_mean * n_zero) / (n_val + n_zero)
        for t, v in val_curve.items()
    }
    new_argmax = max(combined, key=combined.get)
    assert old_argmax == new_argmax
    # but the reported value at the argmax differs (is smaller / more honest)
    assert combined[new_argmax] < val_curve[old_argmax]


def test_backward_compatible_without_candidate_pairs_path(tmp_path):
    """Omitting candidate_pairs_path must reproduce the old (pre-fix)
    behavior exactly, for any caller that hasn't been updated yet."""
    val_preds_path = tmp_path / "val_preds.parquet"
    gt_path = tmp_path / "gt.tsv"
    out_path = tmp_path / "threshold.json"

    _write_val_preds(val_preds_path, [
        {"source1_entity_id": "S1-A", "candidate_entity_id": "S2-A", "score": 0.9},
    ])
    _write_gt(gt_path, [
        {"source1_entity_id": "S1-A", "matched_entity_ids": "S2-A"},
        {"source1_entity_id": "S1-ZERO", "matched_entity_ids": "S2-GHOST"},
    ])

    result = sweep_threshold(val_preds_path, gt_path, out_path)
    assert result["n_zero_candidates_included"] == 0
    assert result["n_population"] == 1  # only S1-A, S1-ZERO still invisible without the path
