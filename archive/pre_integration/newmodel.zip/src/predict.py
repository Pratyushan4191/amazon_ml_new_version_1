import json, numpy as np, pandas as pd, lightgbm as lgb
from pathlib import Path
FEATURE_COLS = ["name_exact", "name_exact_no_suffix", "name_sorted_exact", "name_edit_dist", "name_jaro_winkler", "name_jaro_winkler_ns", "name_token_jaccard", "name_token_set_ratio", "name_token_sort_ratio", "name_char3gram_jaccard", "name_char4gram_jaccard", "name_len_diff", "name_tfidf_cosine", "addr_s1_null", "addr_cand_null", "addr_both_null", "addr_exact", "addr_token_jaccard", "addr_char3gram_jaccard", "addr_house_num_agree", "addr_city_agree", "addr_pin_agree", "addr_tfidf_cosine", "country_match", "high_name_low_addr", "name_sim_x_addr_sim", "n_blocking_rules_hit", "both_have_address", "name_suffix_conflict"]
def run_inference(
    test_features_path,
    model_path,
    threshold_path,
    output_path,
    candidate_pairs_path=None,
    all_s1_ids=None,
):
    model = lgb.Booster(model_file=str(model_path))
    with open(threshold_path) as f: t_star = float(json.load(f)["t_star"])
    test_df = pd.read_parquet(test_features_path)
    if "candidate_entity_id" not in test_df.columns and "candidate_id" in test_df.columns: test_df = test_df.rename(columns={"candidate_id": "candidate_entity_id"})

    all_s1 = (
        list(dict.fromkeys(all_s1_ids))
        if all_s1_ids is not None
        else sorted(test_df["source1_entity_id"].unique().tolist())
    )
    scores = model.predict(test_df[FEATURE_COLS].astype(np.float32))
    test_df["score"] = scores
    match_dict = {s: [] for s in all_s1}
    above = test_df[test_df["score"] >= t_star]

    for s1, grp in above.groupby("source1_entity_id"):
        match_dict[s1] = sorted(list(dict.fromkeys(grp["candidate_entity_id"].tolist())), key=lambda x: (x[:2], int(x[3:]) if x[3:].isdigit() else 0))

    rows = [{"source1_entity_id": k, "matched_entity_ids": ",".join(v)} for k, v in match_dict.items()]
    out_df = pd.DataFrame(rows)
    out_df["matched_entity_ids"] = out_df["matched_entity_ids"].astype(str).replace("nan", "")
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    out_df.to_csv(output_path, sep="\t", index=False, na_rep="")
    return {"total_s1": len(all_s1), "n_singletons": sum(1 for v in match_dict.values() if not v), "singleton_rate": 0.0, "n_matched": 0, "mean_matches": 0.0, "t_star": t_star, "output_path": str(output_path)}
