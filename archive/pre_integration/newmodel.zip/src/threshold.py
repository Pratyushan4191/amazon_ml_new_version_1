import json, numpy as np, pandas as pd
from pathlib import Path
from eval import macro_f05
def sweep_threshold(val_preds_path, ground_truth_path, threshold_output_path, sweep_start=0.01, sweep_stop=0.99, sweep_step=0.01, candidate_col="candidate_entity_id"):
    val_df = pd.read_parquet(val_preds_path)
    gt_df = pd.read_csv(ground_truth_path, sep="\t", dtype=str, keep_default_na=False)
    if candidate_col not in val_df.columns and "candidate_id" in val_df.columns: val_df = val_df.rename(columns={"candidate_id": candidate_col})
    val_s1_ids = val_df["source1_entity_id"].unique().tolist()
    gt_map = {str(r["source1_entity_id"]): set(str(r.get("matched_entity_ids","")).split(",")) - {""} for _, r in gt_df.iterrows()}
    truth_dict = {sid: gt_map.get(sid, set()) for sid in val_s1_ids}

    thresholds = np.round(np.arange(sweep_start, sweep_stop + sweep_step, sweep_step), 4)
    best_t, max_f = 0.5, 0.0
    for t in thresholds:
        above = val_df[val_df["score"] >= t]
        pred_dict = {sid: set() for sid in val_s1_ids}
        for s1_id, grp in above.groupby("source1_entity_id"): pred_dict[s1_id] = set(grp[candidate_col].tolist())
        f05 = macro_f05(pred_dict, truth_dict)
        if f05 >= max_f: best_t, max_f = float(t), float(f05)

    Path(threshold_output_path).parent.mkdir(parents=True, exist_ok=True)
    with open(threshold_output_path, "w") as f: json.dump({"t_star": best_t, "max_f05": max_f}, f, indent=2)
    return {"t_star": best_t, "max_f05": max_f}
