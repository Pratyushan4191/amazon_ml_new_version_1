import json, numpy as np, pandas as pd, lightgbm as lgb
from pathlib import Path
from sklearn.model_selection import GroupShuffleSplit
FEATURE_COLS = ["name_exact", "name_exact_no_suffix", "name_sorted_exact", "name_edit_dist", "name_jaro_winkler", "name_jaro_winkler_ns", "name_token_jaccard", "name_token_set_ratio", "name_token_sort_ratio", "name_char3gram_jaccard", "name_char4gram_jaccard", "name_len_diff", "name_tfidf_cosine", "addr_s1_null", "addr_cand_null", "addr_both_null", "addr_exact", "addr_token_jaccard", "addr_char3gram_jaccard", "addr_house_num_agree", "addr_city_agree", "addr_pin_agree", "addr_tfidf_cosine", "country_match", "high_name_low_addr", "name_sim_x_addr_sim", "n_blocking_rules_hit", "both_have_address", "name_suffix_conflict"]
def train_model(train_features_path, ground_truth_path, model_output_path, shap_output_path, val_preds_output_path, lgbm_params=None, n_estimators=500):
    feat_df = pd.read_parquet(train_features_path)
    gt_df = pd.read_csv(ground_truth_path, sep="\t", dtype=str, keep_default_na=False)
    if "candidate_id" in feat_df.columns: feat_df = feat_df.rename(columns={"candidate_id": "candidate_entity_id"})
    if "label" not in feat_df.columns:
        gt_map = {str(r["source1_entity_id"]): set(str(r.get("matched_entity_ids","")).split(",")) - {""} for _, r in gt_df.iterrows()}
        feat_df["label"] = feat_df.apply(lambda r: int(str(r["candidate_entity_id"]) in gt_map.get(str(r["source1_entity_id"]), set())), axis=1)
    s1_ids = feat_df["source1_entity_id"].unique()
    train_idx, val_idx = next(GroupShuffleSplit(n_splits=1, test_size=0.5, random_state=42).split(np.arange(len(s1_ids)), groups=s1_ids))
    train_df, val_df = feat_df[feat_df["source1_entity_id"].isin(set(s1_ids[train_idx]))], feat_df[feat_df["source1_entity_id"].isin(set(s1_ids[val_idx]))]
    X_train, y_train = train_df[FEATURE_COLS].astype(np.float32), train_df["label"].astype(np.int32)
    X_val, y_val = val_df[FEATURE_COLS].astype(np.float32), val_df["label"].astype(np.int32)
    lgb_train = lgb.Dataset(X_train, label=y_train, feature_name=FEATURE_COLS)
    lgb_val = lgb.Dataset(X_val, label=y_val, feature_name=FEATURE_COLS, reference=lgb_train)
    model = lgb.train(lgbm_params, lgb_train, num_boost_round=n_estimators, valid_sets=[lgb_val])
    Path(model_output_path).parent.mkdir(parents=True, exist_ok=True)
    model.save_model(str(model_output_path))
    val_df = val_df.copy()
    val_df["score"] = model.predict(X_val)
    Path(val_preds_output_path).parent.mkdir(parents=True, exist_ok=True)
    val_df.to_parquet(val_preds_output_path, index=False)
    return {"best_iteration": model.best_iteration, "val_f05_at_0.5": 0.0, "top_features": []}
