"""
Stage 4 (feature generation) equivalence + resume test.

Environment note: this sandbox has no network access, so `rapidfuzz` and
`pyarrow` are not installed. `rapidfuzz` is stubbed (see /home/claude/stubs)
with a deterministic but NOT numerically-real similarity function -- fine
here because this test only checks that the STREAMED chunk-by-chunk Stage 4
produces the IDENTICAL dataframe as the OLD (pre-fix) full-load approach on
the same input, not that the feature VALUES are "correct" in an ML sense.
`pandas.read_parquet`/`to_parquet` are monkeypatched to a pickle-based
stand-in (real pyarrow unavailable) purely so the checkpoint/merge code path
can run end-to-end in this sandbox -- this tests the CONTROL FLOW and
MEMORY ARCHITECTURE (chunking, resume, streaming merge), not real Parquet
I/O itself.
"""
import sys, os, json, shutil, pickle
from pathlib import Path

sys.path.insert(0, "/home/claude/stubs")
sys.path.insert(0, "/home/claude/project")

import pandas as pd

# ---- monkeypatch parquet I/O (pyarrow unavailable in this sandbox) ----
def _fake_to_parquet(self, path, index=False, **kw):
    with open(path, "wb") as f:
        pickle.dump(self, f)

def _fake_read_parquet(path, **kw):
    with open(path, "rb") as f:
        return pickle.load(f)

pd.DataFrame.to_parquet = _fake_to_parquet
pd.read_parquet = _fake_read_parquet

# pyarrow.parquet stand-in used directly by run_pipeline.merge_feature_chunks_streaming
import types
fake_pq = types.ModuleType("pyarrow.parquet")

class _FakeTable:
    def __init__(self, df):
        self.df = df
        self.schema = tuple(df.columns)
        self.num_rows = len(df)
    def cast(self, schema):
        return self
    @staticmethod
    def from_pandas(df):
        return _FakeTable(df)

def _fake_read_table(path):
    with open(path, "rb") as f:
        df = pickle.load(f)
    return _FakeTable(df)

class _FakeWriter:
    def __init__(self, path, schema):
        self.path = path
        self.schema = schema
        self._frames = []
    def write_table(self, table):
        self._frames.append(table.df)
    def close(self):
        out = pd.concat(self._frames, ignore_index=True) if self._frames else pd.DataFrame()
        with open(self.path, "wb") as f:
            pickle.dump(out, f)

fake_pq.read_table = _fake_read_table
fake_pq.ParquetWriter = _FakeWriter
fake_pyarrow = types.ModuleType("pyarrow")
fake_pyarrow.__version__ = "0.0.0-stub"
sys.modules["pyarrow"] = fake_pyarrow
sys.modules["pyarrow.parquet"] = fake_pq

# tqdm passthrough
fake_tqdm_mod = types.ModuleType("tqdm")
def _fake_tqdm(iterable=None, **kw):
    return iterable if iterable is not None else []
fake_tqdm_mod.tqdm = _fake_tqdm
sys.modules["tqdm"] = fake_tqdm_mod

os.chdir("/home/claude/project")

from src.features import (
    load_source_records, load_candidate_pairs, attach_records,
    compute_features, fit_tfidf_from_current_records, iter_exploded_candidate_chunks,
)
import run_pipeline as rp

DATA_DIR = Path("/home/claude/synthtest/data")
CAND_PATH = Path("/home/claude/synthtest/candidate_pairs.tsv")

sources = load_source_records(DATA_DIR, split="train")
tfidf = fit_tfidf_from_current_records(sources)

# ---- OLD approach: full load, no chunking ----
cp_full = load_candidate_pairs(CAND_PATH)
attached_full = attach_records(cp_full, sources)
feat_full = compute_features(attached_full, tfidf)
meta_full = attached_full[["source1_entity_id", "candidate_entity_id", "candidate_source"]].reset_index(drop=True)
old_result = pd.concat([meta_full, feat_full.reset_index(drop=True)], axis=1)

print(f"[OLD full-load] {len(old_result)} exploded candidate-pair rows computed in one shot.")

# ---- NEW approach: streamed, small chunk size to force many chunks ----
ckpt_dir = Path("/home/claude/synthtest/ckpt_run1")
if ckpt_dir.exists():
    shutil.rmtree(ckpt_dir)
out_path = Path("/home/claude/synthtest/train_features_run1.parquet")
if out_path.exists():
    out_path.unlink()

rp.save_features(CAND_PATH, DATA_DIR, "train", tfidf, out_path, ckpt_dir, stage4_chunk_size=37)
new_result = pd.read_parquet(out_path)
print(f"[NEW streamed, chunk_size=37] {len(new_result)} rows written to {out_path.name}.")

# ---- Equivalence check ----
key = ["source1_entity_id", "candidate_entity_id"]
old_sorted = old_result.sort_values(key).reset_index(drop=True)
new_sorted = new_result.sort_values(key).reset_index(drop=True)

assert len(old_sorted) == len(new_sorted), f"ROW COUNT MISMATCH: old={len(old_sorted)} new={len(new_sorted)}"
assert list(old_sorted.columns) == list(new_sorted.columns), (
    f"COLUMN MISMATCH:\nold={list(old_sorted.columns)}\nnew={list(new_sorted.columns)}"
)
import numpy as np
for col in old_sorted.columns:
    if pd.api.types.is_numeric_dtype(old_sorted[col]):
        ok = np.allclose(old_sorted[col].to_numpy(dtype=float), new_sorted[col].to_numpy(dtype=float), atol=1e-9)
    else:
        ok = (old_sorted[col].astype(str) == new_sorted[col].astype(str)).all()
    assert ok, f"VALUE MISMATCH in column {col}"

print("PASS: streamed Stage 4 output is row-for-row, value-for-value identical to the old full-load computation "
      f"({len(old_sorted)} rows, {len(old_sorted.columns)} columns).")

# ---- Chunk count sanity: with 500 S1 rows and chunk_size=37, expect ceil(500/37)=14 raw chunks,
# though some chunks may be entirely singleton (0 exploded rows) and get skipped by the generator.
n_chunks_seen = sum(1 for _ in iter_exploded_candidate_chunks(CAND_PATH, chunk_size=37))
print(f"[chunking] iter_exploded_candidate_chunks yielded {n_chunks_seen} non-empty exploded chunks "
      f"for 500 raw S1 rows at chunk_size=37 (raw chunk count would be {-(-500//37)}, "
      f"difference = chunks with zero candidates, correctly skipped).")

# ---- Resume test: simulate an interruption partway through, then resume ----
ckpt_dir2 = Path("/home/claude/synthtest/ckpt_run2")
if ckpt_dir2.exists():
    shutil.rmtree(ckpt_dir2)
out_path2 = Path("/home/claude/synthtest/train_features_run2.parquet")
if out_path2.exists():
    out_path2.unlink()
ckpt_dir2.mkdir(parents=True)

# Manually pre-seed a "completed" checkpoint for the first 3 chunk indices only,
# using data actually computed by the streaming path itself (chunk 0,1,2),
# to simulate "the process was killed after 3 chunks".
partial_completed = set()
for i, exploded_chunk in enumerate(iter_exploded_candidate_chunks(CAND_PATH, chunk_size=37)):
    if i >= 3:
        break
    chunk = attach_records(exploded_chunk, sources)
    feat = compute_features(chunk, tfidf)
    meta = chunk[["source1_entity_id", "candidate_entity_id", "candidate_source"]].reset_index(drop=True)
    result = pd.concat([meta, feat.reset_index(drop=True)], axis=1)
    ckpt_file = ckpt_dir2 / f"train_chunk_{i:06d}.parquet"
    result.to_parquet(ckpt_file, index=False)
    partial_completed.add(i)

with open(ckpt_dir2 / "train_feature_ckpt_meta.json", "w") as f:
    json.dump({"completed_chunks": list(partial_completed)}, f)

# Now "resume": run save_features again with the same chunk size; it should
# skip chunks 0,1,2 and only compute the rest, then merge everything.
rp.save_features(CAND_PATH, DATA_DIR, "train", tfidf, out_path2, ckpt_dir2, stage4_chunk_size=37)
resumed_result = pd.read_parquet(out_path2)
resumed_sorted = resumed_result.sort_values(key).reset_index(drop=True)

assert len(resumed_sorted) == len(old_sorted), (
    f"RESUME ROW COUNT MISMATCH: resumed={len(resumed_sorted)} full={len(old_sorted)}"
)
for col in old_sorted.columns:
    if pd.api.types.is_numeric_dtype(old_sorted[col]):
        ok = np.allclose(old_sorted[col].to_numpy(dtype=float), resumed_sorted[col].to_numpy(dtype=float), atol=1e-9)
    else:
        ok = (old_sorted[col].astype(str) == resumed_sorted[col].astype(str)).all()
    assert ok, f"RESUME VALUE MISMATCH in column {col}"

print("PASS: resuming from a partial checkpoint (3/14 chunks pre-completed) produces output "
      "identical to a full uninterrupted run.")

# ---- Empty-candidate-set edge case ----
empty_cand_path = Path("/home/claude/synthtest/empty_candidates.tsv")
empty_cand_path.write_text("source1_entity_id\tcandidate_entity_ids\nS1-00000\t\nS1-00001\t\n")
ckpt_dir3 = Path("/home/claude/synthtest/ckpt_run3")
if ckpt_dir3.exists():
    shutil.rmtree(ckpt_dir3)
out_path3 = Path("/home/claude/synthtest/train_features_empty.parquet")
if out_path3.exists():
    out_path3.unlink()
rp.save_features(empty_cand_path, DATA_DIR, "train", tfidf, out_path3, ckpt_dir3, stage4_chunk_size=37)
empty_result = pd.read_parquet(out_path3)
assert len(empty_result) == 0, f"expected 0 rows for all-singleton input, got {len(empty_result)}"
from src.features import FEATURE_COLS
expected_cols = ["source1_entity_id", "candidate_entity_id", "candidate_source"] + list(FEATURE_COLS)
assert list(empty_result.columns) == expected_cols, (
    f"empty-output schema mismatch:\ngot={list(empty_result.columns)}\nexpected={expected_cols}"
)
print("PASS: all-zero-candidate input produces a correctly-schema'd 0-row output file, no crash.")

print("\nALL STAGE 4 TESTS PASSED")
