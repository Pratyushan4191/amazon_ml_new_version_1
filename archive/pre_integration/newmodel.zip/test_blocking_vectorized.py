"""
Regression tests for src/blocking_vectorized.py (Option 3).

NOTE (pipeline audit): blocking_vectorized.py's own module docstring claims
"verified in tests/test_blocking_vectorized.py by direct comparison against
src/blocking.py" -- that file did not exist anywhere in the repository
before this audit. These tests close that gap. They also would have caught
two real bugs found during this audit:
  1. `AttributeError: 'numpy.ndarray' object has no attribute 'values'` in
     `_filter_hot_buckets`, which only fires once a bucket actually reaches
     max_bucket_size (never exercised by any pre-existing fixture).
  2. The pandas-version `np.array_split` incompatibility in the OLD
     implementation that made old-vs-new comparison impossible at all.
"""
import random
import shutil
from pathlib import Path

import pandas as pd
import pytest

from src.blocking import generate_candidate_pairs, export_candidate_pairs_tsv
from src.blocking_vectorized import (
    generate_candidate_pairs_vectorized,
    load_candidate_mapping_from_tsv,
    build_index_table,
    _filter_hot_buckets,
)
from eval import measure_blocking_recall


def _make_synthetic(tmp_path, n_s1=300, n_s2=600, n_s3=600, hot_frac=0.5, n_true=200, seed=7):
    """Small-but-nontrivial synthetic dataset with an embedded hot key
    (many S2/S3 records sharing one name) and a known set of true matches,
    so blocking recall is actually measurable."""
    random.seed(seed)
    countries = ["US", "IN", "DE"]

    def rand_name(i, hot):
        if hot:
            return "GLOBAL LOGISTICS INC"
        return f"{random.choice(['ACME', 'NORTH', 'BLUE'])} {random.choice(['TRADING', 'FOODS'])} {i}"

    def rand_addr(i):
        return f"{random.randint(1, 999)} {random.choice(['MAIN', 'OAK', 'PARK'])} ST, {random.choice(['SPRINGFIELD', 'RIVERTON'])}"

    s1_records = []
    s1_rows = []
    for i in range(n_s1):
        country = random.choice(countries)
        name, addr = rand_name(i, hot=False), rand_addr(i)
        s1_records.append((name, addr, country))
        s1_rows.append({"entity_id": f"S1-{i:06d}", "business_name": name,
                         "business_address": addr, "country": country})

    s2_rows, s3_rows, truth_map = [], [], {r["entity_id"]: [] for r in s1_rows}
    for i in range(n_s2):
        cid = f"S2-{i:06d}"
        if i < n_true:
            name, addr, country = s1_records[i]
            s2_rows.append({"entity_id": cid, "business_name": name, "business_address": addr, "country": country})
            truth_map[f"S1-{i:06d}"].append(cid)
        else:
            hot = random.random() < hot_frac
            s2_rows.append({"entity_id": cid, "business_name": rand_name(i, hot), "business_address": rand_addr(i),
                             "country": random.choice(countries)})
    for i in range(n_s3):
        cid = f"S3-{i:06d}"
        if i < n_true // 2:
            name, addr, country = s1_records[i]
            s3_rows.append({"entity_id": cid, "business_name": name, "business_address": addr, "country": country})
            truth_map[f"S1-{i:06d}"].append(cid)
        else:
            hot = random.random() < hot_frac
            s3_rows.append({"entity_id": cid, "business_name": rand_name(i, hot), "business_address": rand_addr(i),
                             "country": random.choice(countries)})

    s1_df = pd.DataFrame(s1_rows)
    s2_df = pd.DataFrame(s2_rows)
    s3_df = pd.DataFrame(s3_rows)
    gt_df = pd.DataFrame(
        [{"source1_entity_id": k, "matched_entity_ids": ",".join(v)} for k, v in truth_map.items()]
    )
    gt_path = tmp_path / "ground_truth.tsv"
    gt_df.to_csv(gt_path, sep="\t", index=False)
    return s1_df, s2_df, s3_df, gt_path, truth_map


def _run_both(tmp_path, s1_df, s2_df, s3_df, gt_path, max_bucket_size=5000, max_candidates_per_entity=200, chunk_size=100):
    old_map, _ = generate_candidate_pairs(
        s1_df, s2_df, s3_df,
        max_candidates_per_entity=max_candidates_per_entity,
        max_bucket_size=max_bucket_size,
        enable_coarse_filter=True, min_coarse_similarity=0.30,
    )
    vec_ckpt = tmp_path / "vec_ckpt"
    shutil.rmtree(vec_ckpt, ignore_errors=True)
    vec_out = tmp_path / "vec_cands.tsv"
    generate_candidate_pairs_vectorized(
        s1_df, s2_df, s3_df, output_candidate_tsv=str(vec_out),
        max_candidates_per_entity=max_candidates_per_entity,
        max_bucket_size=max_bucket_size,
        enable_coarse_filter=True, min_coarse_similarity=0.30,
        chunk_size=chunk_size, checkpoint_dir=str(vec_ckpt), resume=False,
        logger=lambda *a, **k: None,
    )
    vec_map = load_candidate_mapping_from_tsv(str(vec_out))
    return old_map, vec_map


def test_old_and_vectorized_produce_identical_candidate_sets(tmp_path):
    s1_df, s2_df, s3_df, gt_path, _ = _make_synthetic(tmp_path)
    old_map, vec_map = _run_both(tmp_path, s1_df, s2_df, s3_df, gt_path)
    for s1_id in s1_df["entity_id"]:
        assert set(old_map.get(s1_id, [])) == set(vec_map.get(s1_id, [])), s1_id


def test_blocking_recall_meets_target_and_matches_old(tmp_path):
    s1_df, s2_df, s3_df, gt_path, _ = _make_synthetic(tmp_path)
    old_map, vec_map = _run_both(tmp_path, s1_df, s2_df, s3_df, gt_path)
    old_recall = measure_blocking_recall(old_map, str(gt_path))
    vec_recall = measure_blocking_recall(vec_map, str(gt_path))
    assert old_recall["recall"] == vec_recall["recall"]
    assert vec_recall["recall"] >= 0.95, f"Blocking recall {vec_recall['recall']:.3f} below the 95% architecture target"


def test_hot_key_exclusion_actually_drops_rows_and_preserves_recall(tmp_path):
    """Regression test for the `.values`-on-ndarray AttributeError: this only
    fires when a bucket exceeds max_bucket_size, so a low cap is required to
    exercise it at all."""
    s1_df, s2_df, s3_df, gt_path, _ = _make_synthetic(tmp_path, hot_frac=0.6)
    idx, _ = build_index_table(s2_df, s3_df)
    filtered = _filter_hot_buckets(idx, max_bucket_size=50)
    assert len(filtered) < len(idx), "hot-key protection should drop at least one oversized bucket"

    old_map, vec_map = _run_both(tmp_path, s1_df, s2_df, s3_df, gt_path, max_bucket_size=50)
    for s1_id in s1_df["entity_id"]:
        assert set(old_map.get(s1_id, [])) == set(vec_map.get(s1_id, [])), s1_id
    recall = measure_blocking_recall(vec_map, str(gt_path))
    assert recall["recall"] >= 0.95


def test_candidate_cap_is_enforced(tmp_path):
    s1_df, s2_df, s3_df, gt_path, _ = _make_synthetic(tmp_path, hot_frac=0.9)
    _, vec_map = _run_both(tmp_path, s1_df, s2_df, s3_df, gt_path, max_candidates_per_entity=10)
    for s1_id, cands in vec_map.items():
        assert len(cands) <= 10


def test_empty_s1_and_no_candidates_handled(tmp_path):
    s2_df = pd.DataFrame([{"entity_id": "S2-000001", "business_name": "ACME CO", "business_address": "1 MAIN ST", "country": "US"}])
    s3_df = pd.DataFrame([{"entity_id": "S3-000001", "business_name": "ACME CO", "business_address": "1 MAIN ST", "country": "US"}])
    s1_df = pd.DataFrame([{"entity_id": "S1-000001", "business_name": "TOTALLY UNRELATED ZZZ", "business_address": "9 NOWHERE RD", "country": "DE"}])
    out = tmp_path / "empty_cands.tsv"
    ckpt = tmp_path / "empty_ckpt"
    generate_candidate_pairs_vectorized(
        s1_df, s2_df, s3_df, output_candidate_tsv=str(out),
        max_candidates_per_entity=200, max_bucket_size=5000,
        enable_coarse_filter=True, min_coarse_similarity=0.30,
        chunk_size=10, checkpoint_dir=str(ckpt), resume=False,
        logger=lambda *a, **k: None,
    )
    result = pd.read_csv(out, sep="\t", dtype=str, keep_default_na=False)
    assert len(result) == 1
    assert result.iloc[0]["source1_entity_id"] == "S1-000001"
    assert result.iloc[0]["candidate_entity_ids"] == ""


def test_checkpoint_resume_after_simulated_crash(tmp_path, monkeypatch):
    s1_df, s2_df, s3_df, gt_path, _ = _make_synthetic(tmp_path, n_s1=150, n_s2=300, n_s3=300, n_true=100)
    ckpt = tmp_path / "resume_ckpt"
    out = tmp_path / "resume_cands.tsv"

    import src.blocking_vectorized as bv
    orig = bv._candidates_for_chunk
    call_count = {"n": 0}

    def crashing(*args, **kwargs):
        call_count["n"] += 1
        if call_count["n"] == 2:
            raise RuntimeError("simulated worker crash")
        return orig(*args, **kwargs)

    monkeypatch.setattr(bv, "_candidates_for_chunk", crashing)
    with pytest.raises(RuntimeError):
        generate_candidate_pairs_vectorized(
            s1_df, s2_df, s3_df, output_candidate_tsv=str(out),
            max_candidates_per_entity=200, max_bucket_size=5000,
            enable_coarse_filter=True, min_coarse_similarity=0.30,
            chunk_size=30, checkpoint_dir=str(ckpt), resume=True,
            logger=lambda *a, **k: None,
        )
    completed_before = list(ckpt.glob("chunk_*.parquet"))
    assert len(completed_before) >= 1, "at least one chunk should be safely checkpointed before the crash"

    monkeypatch.setattr(bv, "_candidates_for_chunk", orig)
    generate_candidate_pairs_vectorized(
        s1_df, s2_df, s3_df, output_candidate_tsv=str(out),
        max_candidates_per_entity=200, max_bucket_size=5000,
        enable_coarse_filter=True, min_coarse_similarity=0.30,
        chunk_size=30, checkpoint_dir=str(ckpt), resume=True,
        logger=lambda *a, **k: None,
    )
    resumed_map = load_candidate_mapping_from_tsv(str(out))
    assert len(resumed_map) == len(s1_df)
    recall = measure_blocking_recall(resumed_map, str(gt_path))
    assert recall["recall"] >= 0.95
